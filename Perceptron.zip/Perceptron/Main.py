from Perceptron import Perceptron
import copy
inputs = [[0.1, 0.4, 0.7], [0.3, 0.7, 0.2], [0.6, 0.9, 0.8], [0.5, 0.7, 0.1]]
outputs=[1,-1,-1,1]
rede = Perceptron(inputs,outputs)
test=copy.deepcopy(inputs)
rede.train()
for var in test:
    rede.testar(var,'A','B')
