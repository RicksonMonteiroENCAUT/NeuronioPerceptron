import random as rd

class Perceptron:
	def __init__(self, inputs,outputs,learning_rate=0.1,activation_treshold=-1,epoch=1000):
		self.inputs=inputs
		self.outputs=outputs
		self.learning_rate=learning_rate
		self.epoch=epoch
		self.weights=[]
		self.activation_treshold=activation_treshold


	def signal(self, u):
		return 1 if u >= 0 else -1

	def testar(self, xinput, classe1, classe2):

		xinput.insert(0, 1)

		u = 0
		for i in range(len(xinput)):
			u += self.weights[i] * xinput[i]
		y = self.signal(u)
		if y == -1:
			print('A amostra pertence a classe %s' % classe1)
		else:
			print('A amostra pertence a classe %s' % classe2)

	def train(self):

		for i in range(len(self.inputs[0])):
			self.weights.append(rd.random())
		self.weights.insert(0,self.activation_treshold)

		# len of weights= 4, len of inputs[n] =3
		for c in self.inputs:
			c.insert(0,1)
		# len of inputs[n]=4; lens==
		epochs=0
		while True:
			erro=False
			for i in range(len(self.inputs)):
				u=0
				for j in range(len(self.inputs[i])):
					u+= self.weights[j]*self.inputs[i][j]
				y=self.signal(u)
				if y!=self.outputs[i]:
					erro_aux= self.outputs[i]-y
					for k in range(len(self.inputs)):
						self.weights[k]=self.weights[k] + self.learning_rate * erro_aux * self.inputs[i][k]
					erro=True
			epochs+=1
			if epochs >self.epoch or not erro:
				break










